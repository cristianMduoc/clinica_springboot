package com.duoc.backendClinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
